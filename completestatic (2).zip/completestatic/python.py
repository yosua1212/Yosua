from flask import flask

if __name__ == '__main__':
    flask.run(debug=True)